import { NextResponse } from 'next/server';
import { listGuides, saveGuide, setArchived, importGuides } from '@/lib/sheets';
import { authed } from '@/lib/auth';
export const dynamic = 'force-dynamic';

const deny = () => NextResponse.json({ error: 'الرقم السري غلط' }, { status: 401 });
const fail = e => NextResponse.json({ error: String(e.message || e) }, { status: 500 });

export async function GET(req) {
  if (!authed(req)) return deny();
  try { return NextResponse.json({ guides: await listGuides() }); } catch (e) { return fail(e); }
}
export async function POST(req) {
  if (!authed(req)) return deny();
  try {
    const b = await req.json();
    let guides;
    if (b.action === 'save') guides = await saveGuide(b.oldName, b.name, b.phone);
    else if (b.action === 'archive') guides = await setArchived(b.name, !!b.flag);
    else if (b.action === 'import') guides = await importGuides();
    else return NextResponse.json({ error: 'action غير معروف' }, { status: 400 });
    return NextResponse.json({ guides });
  } catch (e) { return fail(e); }
}
