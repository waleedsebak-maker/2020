import { NextResponse } from 'next/server';
import { readDays } from '@/lib/sheets';
import { authed } from '@/lib/auth';
export const dynamic = 'force-dynamic';

export async function GET(req) {
  if (!authed(req)) return NextResponse.json({ error: 'الرقم السري غلط' }, { status: 401 });
  try { return NextResponse.json({ days: await readDays(1, 7) }); }
  catch (e) { return NextResponse.json({ error: String(e.message || e) }, { status: 500 }); }
}
