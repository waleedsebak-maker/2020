import { NextResponse } from 'next/server';
import webpush from 'web-push';
import { readDays, listSubs, removeSub, cairoHour } from '@/lib/sheets';
export const dynamic = 'force-dynamic';

export async function GET(req) {
  const secret = process.env.CRON_SECRET;
  if (!secret || req.headers.get('authorization') !== `Bearer ${secret}`)
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const force = new URL(req.url).searchParams.get('force') === '1';
  // الـ cron بيشتغل 6 و7 UTC؛ نبعت بس لما الساعة 9 بتوقيت القاهرة (بيراعي التوقيت الصيفي)
  if (!force && cairoHour() !== 9) return NextResponse.json({ skipped: true, hour: cairoHour() });
  try {
    webpush.setVapidDetails('mailto:' + (process.env.VAPID_EMAIL || 'admin@example.com'),
      process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY, process.env.VAPID_PRIVATE_KEY);
    const [d] = await readDays(1, 1);
    const body = !d.found ? 'تاب بكرة مش موجود في الشيت'
      : d.rows.length ? `${d.rows.length} تشغيل — ${d.rows.filter(r => r.dir === 'CAI').length} قاهرة / ${d.rows.filter(r => r.dir === 'LUX').length} أقصر`
      : 'لا توجد تشغيلات';
    const payload = JSON.stringify({ title: 'تصاريح ' + d.label, body, url: '/?start=1' });
    let sent = 0;
    for (const s of await listSubs()) {
      try { await webpush.sendNotification(JSON.parse(s.json), payload); sent++; }
      catch (e) { if (e.statusCode === 404 || e.statusCode === 410) await removeSub(s.row); }
    }
    return NextResponse.json({ sent, rows: d.rows.length });
  } catch (e) { return NextResponse.json({ error: String(e.message || e) }, { status: 500 }); }
}
